import mongoose from "mongoose";

const Schema = mongoose.Schema;
const toDoSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  done: { type: Boolean, default: false },
});

const schemaToDo = mongoose.model("To Do Task", toDoSchema);

export default schemaToDo;
