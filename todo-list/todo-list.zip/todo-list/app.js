import express from "express";
import mongoose from "mongoose";
import toDorouter from "./routers/todo.js";

const app = express();
const PORT = 8000;

mongoose
  .connect(
    "mongodb+srv://seabdelrahman968:OublQOC0osuc0aAD@cluster0.lyrwb.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
  )
  .then(() => {
    console.log(`Connection To MongoDB Is OK!`);
  })
  .catch((err) => {
    console.log(`Error with MongoDB`, err);
  });

app.use(express.json());

app.use(toDorouter);

app.listen(PORT, () => {
  console.log(`server is up at: http://localhost:${PORT}`);
});
