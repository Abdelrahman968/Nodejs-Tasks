import express from "express";
import toDoSchema from "../models/todoMod.js";

const router = express.Router();

router.post("/todo", async (req, res) => {
  const { title, description, done } = req.body;

  if (!title || !description) {
    return res
      .status(400)
      .json({ error: "Title and Description are required." });
  }

  try {
    const newToDoList = new toDoSchema({
      title,
      description,
      done,
    });
    await newToDoList.save();
    res.status(201).send(newToDoList);
  } catch (err) {
    res.status(400).json({ error: "Error with Post", message: err.message });
  }
});

router.get("/todo", async (req, res) => {
  try {
    const showToDoList = await toDoSchema.find();
    if (!showToDoList) {
      return res.status(404).json({ message: "To Do List not found!" });
    }
    res.status(200).send(showToDoList);
  } catch (err) {
    res.status(400).json({ error: "Error with Get", message: err.message });
  }
});
router.get("/todo/:ID", async (req, res) => {
  const taskID = req.params.ID;
  try {
    const showToDoList = await toDoSchema.findById(taskID);
    if (!showToDoList) {
      return res.status(404).json({ message: "To Do List not found!" });
    }
    res.status(200).send(showToDoList);
  } catch (err) {
    res.status(400).json({ error: "Error with Get", message: err.message });
  }
});

router.put("/todo/:ID", async (req, res) => {
  const updateData = req.body;
  const taskID = req.params.ID;

  if (!req.body.title || !req.body.description) {
    return res
      .status(400)
      .json({ error: "Title and Description are required." });
  }

  try {
    const updateToDoList = await toDoSchema.findByIdAndUpdate(
      taskID,
      updateData,
      {
        new: true,
      }
    );
    if (!updateToDoList) {
      return res.status(404).json({ message: "To Do List not found!" });
    }

    res.status(200).send(updateToDoList);
  } catch (err) {
    res.status(400).json({ error: "Error with PUT", message: err.message });
  }
});

router.delete("/todo/:ID", async (req, res) => {
  const taskID = req.params.ID;

  try {
    const deleteToDoList = await toDoSchema.findByIdAndDelete(taskID);
    if (!deleteToDoList) {
      return res.status(404).json({ message: "To Do List not found!" });
    }
    res.status(200).json({ message: "Deleted Done", Task: deleteToDoList });
  } catch (err) {
    res.status(400).json({ error: "Error with Delete", message: err.message });
  }
});

export default router;
